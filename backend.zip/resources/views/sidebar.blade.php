<ul class=" navbar-nav sidebar sidebar accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{route('home')}}">
        <div class="sidebar-brand-icon">

        </div>
        <div class="sidebar-brand-text text-dark mx-3">Sistema gestión de vehiculos</div>
    </a>
    <hr class="sidebar-divider my-0">

    <li class="nav-item">
        <a class="nav-link collapsed text text-dark" href="#" data-toggle="collapse" data-target="#collapseBootstrap"
            aria-expanded="true" aria-controls="collapseBootstrap">
            <i class="fa fa-cogs"></i>
            <span>Gerencia</span>
        </a>
        <div id="collapseBootstrap" class="collapse" aria-labelledby="headingBootstrap" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="#">Administradores</a>
            </div>
        </div>
    </li>


    <hr class="sidebar-divider">
    <div class="version" id="version-ruangadmin"></div>


</ul>