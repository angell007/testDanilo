export function PickButtonAspect(buttonHTML){
    return {
        getButtonHTML : () => buttonHTML
    }
}