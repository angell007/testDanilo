
var formClienteRegister = document.getElementById('formClienteRegister');
formClienteRegister.addEventListener('submit', ajaxFormRegisterCliente);

var formClienteUpdate = document.getElementById('formClienteUpdate');
formClienteUpdate.addEventListener('submit', ajaxFormUpdateCliente);