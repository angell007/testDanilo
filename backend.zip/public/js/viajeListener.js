
// var formViajeRegister = document.getElementById('formViajeRegister');
// formViajeRegister.addEventListener('submit', ajaxFormRegisterViaje);

// var formViajeUpdate = document.getElementById('formViajeUpdate');
// formViajeUpdate.addEventListener('submit', ajaxFormUpdateViaje);